'use strict';
const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 1e5 });
const PORT = Number(process.env.PORT || 3000);
const dbPath = process.env.DATABASE_PATH || path.join(__dirname, 'game.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS players (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, x REAL NOT NULL DEFAULT 0, z REAL NOT NULL DEFAULT 0,
  money INTEGER NOT NULL DEFAULT 350, hunger INTEGER NOT NULL DEFAULT 90, energy INTEGER NOT NULL DEFAULT 90,
  fun INTEGER NOT NULL DEFAULT 70, hygiene INTEGER NOT NULL DEFAULT 80, job TEXT, home TEXT,
  car TEXT, updated_at INTEGER NOT NULL
)`);
const selectPlayer = db.prepare('SELECT * FROM players WHERE id = ?');
const upsertPlayer = db.prepare(`INSERT INTO players (id,name,x,z,money,hunger,energy,fun,hygiene,job,home,car,updated_at)
VALUES (@id,@name,@x,@z,@money,@hunger,@energy,@fun,@hygiene,@job,@home,@car,@updated_at)
ON CONFLICT(id) DO UPDATE SET name=excluded.name,x=excluded.x,z=excluded.z,money=excluded.money,hunger=excluded.hunger,
energy=excluded.energy,fun=excluded.fun,hygiene=excluded.hygiene,job=excluded.job,home=excluded.home,car=excluded.car,updated_at=excluded.updated_at`);
const publicPlayer = p => ({ id:p.id, name:p.name, x:p.x, z:p.z, money:p.money, hunger:p.hunger, energy:p.energy, fun:p.fun, hygiene:p.hygiene, job:p.job, home:p.home, car:p.car });
const online = new Map();
const jobs = {
  'Cafe Barista': { pay: 85, energy: 13, fun: 2 },
  'Rideshare Driver': { pay: 115, energy: 17, fun: -2 },
  'Film Set Assistant': { pay: 150, energy: 20, fun: 8 },
  'Real Estate Agent': { pay: 135, energy: 14, fun: 3 },
  'Food Courier': { pay: 95, energy: 15, fun: 0 }
};
const homes = { 'Studio Apartment': { price: 500, rent: 45 }, 'Venice Bungalow': { price: 2200, rent: 90 }, 'Hollywood Hills Villa': { price: 9000, rent: 180 } };
const cars = { 'City Compact': { price: 700 }, 'Sunset Coupe': { price: 2200 }, 'Beverly Luxury': { price: 6500 } };
const clamp = n => Math.max(0, Math.min(100, n));
function cleanName(v) { return String(v || 'New Angel').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 18) || 'New Angel'; }
function loadOrCreate(id, name) {
  let p = selectPlayer.get(id);
  if (!p) {
    p = { id, name: cleanName(name), x: (Math.random()-.5)*8, z: (Math.random()-.5)*8, money:350, hunger:90, energy:90, fun:70, hygiene:80, job:null, home:null, car:null, updated_at:Date.now() };
    upsertPlayer.run(p);
  } else if (name && p.name !== cleanName(name)) { p.name = cleanName(name); upsertPlayer.run({...p, updated_at:Date.now()}); }
  return selectPlayer.get(id);
}
function save(p) { p.updated_at = Date.now(); upsertPlayer.run(p); }
function notifyPlayer(socket, p, message) { socket.emit('state', { player: publicPlayer(p), message }); }
function getPlayer(socket) { return selectPlayer.get(socket.data.playerId); }

app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));
app.get('/health', (_req,res) => res.json({ ok:true, game:'Los Angeles Life', online:online.size }));
app.get('/api/world', (_req,res) => res.json({ jobs, homes, cars, online:online.size }));

io.on('connection', socket => {
  socket.on('join', payload => {
    const id = String(payload?.id || socket.id).slice(0, 64);
    socket.data.playerId = id;
    const p = loadOrCreate(id, payload?.name);
    online.set(id, socket.id);
    socket.join('city');
    notifyPlayer(socket, p, `Welcome to Los Angeles, ${p.name}. Your life starts here.`);
    socket.emit('world', { players:[...io.sockets.adapter.rooms.get('city') || []].map(sid => {
      const s=io.sockets.sockets.get(sid); return s ? selectPlayer.get(s.data.playerId) : null;
    }).filter(Boolean).map(publicPlayer) });
    io.to('city').emit('presence', { online: online.size });
    io.to('city').emit('playerJoined', publicPlayer(p));
  });

  socket.on('move', pos => {
    const p = getPlayer(socket); if (!p || !pos) return;
    const x = Number(pos.x), z = Number(pos.z);
    if (!Number.isFinite(x) || !Number.isFinite(z)) return;
    p.x = Math.max(-180, Math.min(180, x)); p.z = Math.max(-180, Math.min(180, z));
    save(p);
    socket.to('city').emit('playerMoved', { id:p.id, x:p.x, z:p.z });
  });

  socket.on('action', action => {
    const p = getPlayer(socket); if (!p || !action || typeof action.type !== 'string') return;
    let message = '';
    if (action.type === 'work') {
      const job = jobs[action.job];
      if (!job) return notifyPlayer(socket,p,'That job is not available.');
      if (p.energy < 12) return notifyPlayer(socket,p,'You are too tired to work. Rest at home first.');
      p.job = action.job; p.money += job.pay; p.energy = clamp(p.energy-job.energy); p.hunger=clamp(p.hunger-8); p.fun=clamp(p.fun+job.fun); p.hygiene=clamp(p.hygiene-5);
      message = `Shift complete: ${action.job}. You earned $${job.pay}.`;
    } else if (action.type === 'eat') {
      if (p.money < 18) return notifyPlayer(socket,p,'You need $18 for a meal. Find a job first.');
      p.money -= 18; p.hunger=clamp(p.hunger+32); p.fun=clamp(p.fun+4); message='You grabbed a meal for $18.';
    } else if (action.type === 'rest') {
      if (p.home && p.money >= homes[p.home].rent) { p.money -= homes[p.home].rent; p.energy=clamp(p.energy+48); p.hygiene=clamp(p.hygiene+8); message=`You rested at home. Daily living cost: $${homes[p.home].rent}.`; }
      else { p.energy=clamp(p.energy+25); message='You took a break at the beach. Energy restored a little.'; }
    } else if (action.type === 'shower') {
      p.hygiene=clamp(p.hygiene+38); p.energy=clamp(p.energy-3); message='Freshened up. Hygiene improved.';
    } else if (action.type === 'fun') {
      if (p.money < 25) return notifyPlayer(socket,p,'You need $25 for a night out.');
      p.money-=25; p.fun=clamp(p.fun+30); p.energy=clamp(p.energy-7); message='You enjoyed a night out in the city. ($25)';
    } else if (action.type === 'buyHome') {
      const h=homes[action.home]; if(!h) return;
      if(p.money<h.price) return notifyPlayer(socket,p,`You need $${h.price} to rent/buy this place.`);
      p.money-=h.price; p.home=action.home; p.energy=clamp(p.energy+10); message=`You moved into ${action.home}!`;
    } else if (action.type === 'buyCar') {
      const c=cars[action.car]; if(!c) return;
      if(p.money<c.price) return notifyPlayer(socket,p,`You need $${c.price} for this vehicle.`);
      p.money-=c.price; p.car=action.car; message=`You bought the ${action.car}. Walk around the city to explore; driving is coming in a future update.`;
    } else if (action.type === 'payBills') {
      if(p.money<60) return notifyPlayer(socket,p,'You need $60 to pay your bills.');
      p.money-=60; p.hygiene=clamp(p.hygiene+4); message='Monthly bills paid: $60.';
    } else if (action.type === 'rename') {
      p.name=cleanName(action.name); message=`Your name is now ${p.name}.`;
    } else return;
    save(p); notifyPlayer(socket,p,message); io.to('city').emit('playerUpdated',publicPlayer(p));
  });

  socket.on('chat', raw => {
    const p=getPlayer(socket); if(!p) return;
    const text=String(raw||'').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,180);
    if(!text) return;
    io.to('city').emit('chat', { id:p.id, name:p.name, text, at:Date.now() });
  });

  socket.on('disconnect', () => {
    const id=socket.data.playerId; if(!id) return;
    if(online.get(id)===socket.id) online.delete(id);
    io.to('city').emit('playerLeft',{id}); io.to('city').emit('presence',{online:online.size});
  });
});

// Light passive needs decay while a character is connected. Persistence keeps progress between visits.
setInterval(() => {
  const now=Date.now();
  for (const id of online.keys()) {
    const p=selectPlayer.get(id); if(!p) continue;
    const elapsed=Math.max(0,Math.min(5,(now-p.updated_at)/60000));
    if(elapsed>0) { p.hunger=clamp(p.hunger-elapsed*1.4); p.energy=clamp(p.energy-elapsed*.55); p.fun=clamp(p.fun-elapsed*.35); p.hygiene=clamp(p.hygiene-elapsed*.4); save(p); }
  }
}, 30000).unref();

server.listen(PORT, '0.0.0.0', () => console.log(`Los Angeles Life running on ${PORT}`));
