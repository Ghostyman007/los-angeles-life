# Los Angeles Life

A mobile-friendly 3D browser life simulator with real-time multiplayer presence/chat and server-side saved character progress. Built with Three.js, Express, Socket.IO, and SQLite. Original stylized procedural 3D environment; no proprietary Lagoslife assets or code are included.

## Features in this MVP

- 3D third-person city with original procedural buildings, roads, palm trees, water and character models.
- Mobile joystick and desktop WASD/arrow-key movement.
- Live player presence and synchronized character movement.
- City-wide text chat.
- Jobs with pay and needs trade-offs.
- Hunger, energy, fun and hygiene meters; food, rest, shower, nightlife and bill actions.
- Housing and vehicle ownership purchases.
- Persistent player balance, needs, name, job, housing, car and last position in SQLite.
- `/health` health endpoint and `/api/world` game configuration endpoint.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000` on a phone or computer. The 3D renderer downloads Three.js from jsDelivr, so internet access is needed in the browser. The backend stores data in `./game.sqlite` by default.

## Deploy on Render

1. Create a GitHub repository named `los-angeles-life`.
2. Upload all files and folders from this project to the repository root. Keep `package.json`, `server.js`, `render.yaml`, and `public/index.html` in the root / expected paths.
3. In Render, choose **New + → Blueprint** and connect the GitHub repository. Render reads `render.yaml` and creates the Node web service plus a persistent disk mounted at `/var/data`.
4. Confirm the environment has `DATABASE_PATH=/var/data/game.sqlite`; keep the persistent disk attached so saved characters survive redeploys.
5. Deploy and open the generated `https://...onrender.com` URL on your iPhone.
6. Test `/health` and then enter the game from two separate browser profiles/devices to test multiplayer.

If you create the service manually instead of using the Blueprint, use:
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/health`
- Add a persistent disk mounted at `/var/data`, and set `DATABASE_PATH=/var/data/game.sqlite`.

## Mobile-only deployment

You can do this from an iPhone using GitHub's mobile website and Render's website: create a repository, add the files using **Add file → Create new file** (or upload the extracted project files if your browser offers upload), then create the Render Blueprint from that repository. A zip file itself is not a running website; Render needs the code in a connected repository or another supported deployment source.

## Important production notes

This is a functional MVP, not a finished commercial MMO. It uses an anonymous browser-generated player ID for persistence and is not an identity system; clearing browser storage or switching profiles creates a different character. Add account authentication, rate limiting, chat moderation/reporting, server-authoritative movement validation, backups, abuse prevention, and load testing before a public launch. Online counts and character positions are real-time, but economic actions and saved character records are server-side. The car system currently records ownership; driveable vehicle controls are not yet implemented. The map is a stylized fictionalized LA-inspired district, not a geographically exact replica. Do not store sensitive personal information in chat or player names.
